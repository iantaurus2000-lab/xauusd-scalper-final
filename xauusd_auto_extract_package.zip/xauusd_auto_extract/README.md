# Cara Pakai Auto Extract (Hanya Upload ZIP)

GitHub tidak bisa auto-extract ZIP secara native.  
Cara di bawah ini membuat workflow yang **otomatis mengekstrak** ZIP setelah Anda upload.

## Langkah-langkah (dari HP)

### 1. Buat Repository Baru
- Buka github.com di HP
- Klik **+** → **New repository**
- Nama bebas (contoh: `xauusd-pro`)
- Public
- **Jangan** centang Add README
- Create repository

### 2. Upload 2 File Ini Dulu (penting)
Upload file-file berikut ke repository (satu per satu atau sekaligus):

1. File `README.md` (file ini)
2. Folder `.github` (di dalamnya ada `workflows/auto-extract.yml`)

Cara upload:
- Klik **Add file** → **Upload files**
- Pilih file/folder di atas
- Commit changes

### 3. Upload ZIP Project
1. Kembali ke halaman repository
2. Klik **Add file** → **Upload files**
3. Pilih file **`xauusd_pro_scalper_gratis.zip`**
4. Commit changes

### 4. Jalankan Auto Extract
1. Masuk ke tab **Actions**
2. Pilih workflow **Auto Extract ZIP**
3. Klik **Run workflow** → **Run workflow**
4. Tunggu 1–2 menit sampai selesai (hijau)

Setelah itu, semua file project akan muncul otomatis di repository.

### 5. Build APK
Setelah extract selesai, akan ada workflow **Build APK (Gratis)** (dari project).  
Jalankan workflow tersebut untuk mendapatkan file APK.

---

## Ringkasan
1. Upload `.github` + README dulu
2. Upload file ZIP
3. Jalankan **Auto Extract ZIP**
4. Jalankan **Build APK (Gratis)**
5. Download APK

Selesai.
